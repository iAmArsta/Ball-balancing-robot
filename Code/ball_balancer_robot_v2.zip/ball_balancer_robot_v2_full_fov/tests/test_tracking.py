from ball_balancer.config import CONFIG
from ball_balancer.tracking import BallKalman

def test_kalman():
    k=BallKalman(CONFIG.kalman);k.update(1,2);k.predict(.02);assert k.state().valid
