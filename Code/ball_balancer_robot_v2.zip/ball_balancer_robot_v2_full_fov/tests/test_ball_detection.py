import numpy as np
import cv2
from ball_balancer.config import CameraConfig
from ball_balancer.vision import BallTracker


def test_green_ball_detected_without_camera():
    # Exercise image pipeline using a synthetic image: no Raspberry Pi hardware needed.
    tracker=BallTracker.__new__(BallTracker)
    tracker.cfg=CameraConfig(hsv_lower=(40,90,70),hsv_upper=(85,255,255),
                             min_ball_radius_px=7,max_ball_radius_px=70)
    tracker.plate_radius_mm=75.0
    tracker.missing=0
    from ball_balancer.calibration import PlateCalibration
    tracker.cal=PlateCalibration()
    frame=np.zeros((480,640,3),dtype=np.uint8)
    cv2.circle(frame,(320,240),26,(0,255,0),-1)
    tracker.capture_roi=lambda:frame
    obs=tracker.read()
    assert obs.found and abs(obs.radius_px-26)<2 and obs.diagnosis.startswith('ACCEPTED')


def test_rejection_reason_identifies_too_small():
    tracker=BallTracker.__new__(BallTracker)
    tracker.cfg=CameraConfig(hsv_lower=(40,90,70),hsv_upper=(85,255,255),
                             min_ball_radius_px=20,max_ball_radius_px=70)
    tracker.plate_radius_mm=75.0
    tracker.missing=0
    from ball_balancer.calibration import PlateCalibration
    tracker.cal=PlateCalibration()
    frame=np.zeros((480,640,3),dtype=np.uint8)
    cv2.circle(frame,(320,240),10,(0,255,0),-1)
    tracker.capture_roi=lambda:frame
    obs=tracker.read()
    assert not obs.found and 'radius' in obs.diagnosis
