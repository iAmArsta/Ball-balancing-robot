from ball_balancer.pid import PIDController

def test_output_clamp():
    p=PIDController(10,0,0,2,10,10,0,1);assert p.update(10,.01)==2
