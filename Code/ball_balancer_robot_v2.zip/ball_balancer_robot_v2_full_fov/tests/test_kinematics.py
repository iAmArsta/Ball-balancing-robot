from ball_balancer.config import CONFIG
from ball_balancer.kinematics import ThreeRRSKinematics,PlatePose

def test_level():
    a=ThreeRRSKinematics(CONFIG.geometry).solve(PlatePose());assert len(a)==3

def test_small_tilts():
    k=ThreeRRSKinematics(CONFIG.geometry)
    for r,p in [(3,0),(-3,0),(0,3),(0,-3),(3,3)]:assert len(k.solve(PlatePose(r,p)))==3
