# Raspberry Pi 5 3-servo ball-balancing robot v2

Designed for a transparent circular plate, Camera Module 3 Wide below the plate, three outward-facing MG90S servos, PCA9685, and Raspberry Pi 5.

## Architecture
- `config.py`: **all geometry, channels, camera, control and calibration variables**
- `vision.py`: Picamera2 + HSV/contour detector
- `calibration.py`: 4-point planar homography, pixels -> real plate mm
- `tracking.py`: constant-velocity Kalman filter, position + velocity
- `pid.py`: PID, low-pass derivative, anti-windup
- `controller.py`: X/Y PID + velocity damping -> roll/pitch
- `kinematics.py`: analytic 3-RRS inverse kinematics
- `servos.py`: PCA9685 + calibration + velocity/acceleration limiting
- `logger.py`: CSV logs
- `leveling.py`: conservative drift-based trim estimator
- `main.py`: real-time integration and safety behavior

Reference architecture was informed by open-source 3-RRS / 3-servo ball balancing projects, including JanMaslowski/3RRS-ball-ballancing-platform and thomasonzhou/parallel_manipulator. This code is independently written for this hardware layout.

## Wiring
PCA9685 servo channels are **0, 1, 2** by default. PCA9685 SDA -> Pi GPIO2, SCL -> GPIO3, VCC -> Pi 3.3V, GND -> Pi GND. Power servo `V+` from a separate regulated 5-6 V supply with common ground. Do not power loaded MG90S servos from the Pi 5 V pin.


## Camera Module 3 Wide full-FOV defaults
This build is preconfigured to show the whole Camera Module 3 Wide field of view during plate calibration:
- Processing/output stream: `1280 x 720`
- Frame rate: `50 fps`
- Forced sensor mode: `2304 x 1296`, 10-bit
- Software ROI: `(0, 0, 1280, 720)` (no crop)

When a camera tool starts, it prints the selected main/sensor configuration. If your Raspberry Pi camera stack rejects the forced sensor mode, set `force_sensor_mode = False` in `ball_balancer/config.py` and run again.

## First setup
```bash
chmod +x install.sh
./install.sh
source .venv/bin/activate
```
Check I2C: `i2cdetect -y 1` (normally PCA9685 appears at `40`). Check camera with `rpicam-hello`.

### 1. Measure mechanics and edit `ball_balancer/config.py`
Measure center-to-center, not plastic edge-to-edge:
- `servo_circle_radius_mm`
- `arm1_length_mm`
- `arm2_length_mm`
- `plate_joint_radius_mm`
- `plate_radius_mm`
- `plate_height_mm`

The default dimensions are placeholders and are not guaranteed to match your build.

### 2. Servo calibration
**Disconnect rods/plate before doing this.**
```bash
python -m tools.servo_calibration
```
For each servo determine its safe neutral and direction. Put these into `ServoChannelConfig`. `horn_zero_deg` is the IK horn angle corresponding to that servo's physical neutral.

### 3. Check the configured workspace
```bash
python main.py --workspace-check
```
If it reports unreachable poses, reduce max tilt or correct geometry before attaching the mechanism.

### 4. Calibrate camera coordinates
```bash
python -m tools.plate_calibration
```
Click the four plate edge cardinal points in the requested order. This stores `calibration.json` and handles perspective plus axis orientation. This is preferable to a simple pixels/mm scale, especially with the Wide camera.

### 5. Tune ball color
```bash
python -m tools.hsv_tuner
```
Copy the printed HSV values into `config.py`.

### 6. Dry run
```bash
python main.py --dry-run
```
Confirm the on-screen X/Y signs. If you physically move the ball toward +X, the displayed X should move positive according to the coordinate system you selected during calibration.

### 7. Run
```bash
python main.py
```
Keys: `q`/Esc quits, `r` resets PID + Kalman state.

## PID tuning
Start with `ki=0`, `kd=0`, and low `kp`. Increase `kp` until the ball returns toward center but starts to oscillate; reduce slightly. Add `kd` until oscillation is damped. Add only a small `ki` if a persistent bias remains. The velocity-damping terms use the Kalman velocity estimate and can reduce overshoot.

If the plate tilts the wrong way for an X or Y error, change `pitch_from_x_sign` / `roll_from_y_sign`, not random servo directions. Servo `direction` is only for matching each physical servo's angular convention.

## Static leveling helper
`python -m tools.level_trim` estimates a **small** trim from observed ball drift. It is not a replacement for mechanical leveling or an IMU. Repeat runs and verify the proposed correction direction before applying it in `trim_roll_deg` and `trim_pitch_deg`.

## Logs
Every run writes `logs/run_*.csv`. Plot X/Y position:
```bash
python -m tools.plot_log logs/run_YYYYMMDD_HHMMSS.csv
```

## Safety
MG90S gears can be damaged by a bad IK/configuration. Always calibrate without links attached first, constrain servo min/max angles, use `--dry-run`, then attach links and test with small `max_plate_tilt_deg` (2-3 degrees) before increasing it.

## Running tools directly or as modules
The calibration utilities support both forms from the project root:

```bash
python -m tools.servo_calibration
# or
python tools/servo_calibration.py
```

If you move a tool outside the project folder, keep the `ball_balancer/` package next to `tools/` or use the project root as the working directory.
