"""PCA9685 servo interface with calibration, velocity and acceleration limiting."""
from __future__ import annotations
import time
from typing import Iterable
from .config import ServoConfig

class ServoController:
    def __init__(self,cfg:ServoConfig,dry_run:bool=False):
        self.cfg=cfg; self.dry_run=dry_run; self.kit=None
        self.last=[c.neutral_deg for c in cfg.channels]; self.vel=[0.0]*3; self.last_t=time.monotonic()
        if not dry_run:
            from adafruit_servokit import ServoKit
            self.kit=ServoKit(channels=16,address=cfg.i2c_address,frequency=cfg.pwm_frequency_hz)
            for c in cfg.channels:
                s=self.kit.servo[c.channel]; s.actuation_range=c.actuation_range_deg
                s.set_pulse_width_range(c.min_pulse_us,c.max_pulse_us)

    def horn_to_servo(self,horn:list[float])->list[float]:
        out=[]
        for a,c in zip(horn,self.cfg.channels):
            cmd=c.neutral_deg+c.direction*(a-c.horn_zero_deg)+c.offset_deg
            out.append(max(c.min_deg,min(c.max_deg,cmd)))
        return out

    def command_horn_angles(self,horn:Iterable[float],dt:float|None=None)->list[float]:
        return self.command_servo_angles(self.horn_to_servo(list(horn)),dt)

    def command_servo_angles(self,target:Iterable[float],dt:float|None=None)->list[float]:
        now=time.monotonic(); dt=max(1e-3, now-self.last_t if dt is None else dt); self.last_t=now
        result=[]
        for i,(t,c) in enumerate(zip(target,self.cfg.channels)):
            t=max(c.min_deg,min(c.max_deg,float(t)))
            desired_v=max(-self.cfg.max_speed_deg_per_s,min(self.cfg.max_speed_deg_per_s,(t-self.last[i])/dt))
            dv=max(-self.cfg.max_accel_deg_per_s2*dt,min(self.cfg.max_accel_deg_per_s2*dt,desired_v-self.vel[i]))
            self.vel[i]+=dv
            cmd=self.last[i]+self.vel[i]*dt
            if (t-self.last[i])*(t-cmd) < 0: cmd=t; self.vel[i]=0.0
            if abs(cmd-self.last[i])<self.cfg.command_deadband_deg: cmd=self.last[i]
            cmd=max(c.min_deg,min(c.max_deg,cmd)); self.last[i]=cmd; result.append(cmd)
            if self.kit is not None:self.kit.servo[c.channel].angle=cmd
        return result

    def move_to_horn_angles(self,horn:Iterable[float],duration_s:float|None=None):
        target=self.horn_to_servo(list(horn)); dur=self.cfg.startup_move_time_s if duration_s is None else duration_s
        start=self.last[:]; n=max(2,int(dur*50))
        for k in range(1,n+1):
            u=k/n; smooth=u*u*(3-2*u)
            vals=[a+(b-a)*smooth for a,b in zip(start,target)]
            if self.kit is not None:
                for v,c in zip(vals,self.cfg.channels): self.kit.servo[c.channel].angle=v
            self.last=vals; time.sleep(dur/n)
        self.vel=[0.0]*3
        return self.last[:]

    def close(self):
        if self.kit is not None and self.cfg.disable_outputs_on_exit:
            for c in self.cfg.channels:self.kit.servo[c.channel].angle=None
