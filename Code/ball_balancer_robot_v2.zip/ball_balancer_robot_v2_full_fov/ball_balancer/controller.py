"""2-axis plate controller: PID position feedback + velocity damping + trim."""
from __future__ import annotations
import math
from dataclasses import dataclass
from .config import ControlConfig, PIDAxisConfig
from .pid import PIDController
from .tracking import BallState

@dataclass
class ControllerDebug:
    ex: float=0.; ey: float=0.; x_pid: float=0.; y_pid: float=0.; roll: float=0.; pitch: float=0.

def mk(c: PIDAxisConfig):
    return PIDController(c.kp,c.ki,c.kd,c.output_limit_deg,c.integral_limit,
                         c.derivative_cutoff_hz,c.deadband_mm,c.anti_windup_gain)

class PlateController:
    def __init__(self,cfg:ControlConfig):
        self.cfg=cfg; self.x_pid=mk(cfg.x_pid); self.y_pid=mk(cfg.y_pid); self.debug=ControllerDebug()
    def reset(self): self.x_pid.reset(); self.y_pid.reset()
    def update(self,s:BallState,dt:float)->tuple[float,float]:
        ex=self.cfg.target_x_mm-s.x_mm; ey=self.cfg.target_y_mm-s.y_mm
        ux=self.x_pid.update(ex,dt)-self.cfg.velocity_damping_x_deg_per_mm_s*s.vx_mm_s
        uy=self.y_pid.update(ey,dt)-self.cfg.velocity_damping_y_deg_per_mm_s*s.vy_mm_s
        pitch=self.cfg.pitch_from_x_sign*ux+self.cfg.trim_pitch_deg
        roll=self.cfg.roll_from_y_sign*uy+self.cfg.trim_roll_deg
        mag=math.hypot(roll,pitch)
        if mag>self.cfg.max_plate_tilt_deg:
            k=self.cfg.max_plate_tilt_deg/mag; roll*=k; pitch*=k
        self.debug=ControllerDebug(ex,ey,ux,uy,roll,pitch)
        return roll,pitch
