"""Pixel-to-plate coordinate calibration using a 4-point planar homography."""
from __future__ import annotations
import json, os
from dataclasses import dataclass
import cv2, numpy as np

@dataclass
class PlateCalibration:
    H_px_to_mm: np.ndarray|None=None
    H_mm_to_px: np.ndarray|None=None
    center_px: tuple[float,float]|None=None
    radius_px: float|None=None

    @classmethod
    def load(cls,path:str):
        if not os.path.exists(path): return cls()
        d=json.load(open(path))
        H=np.array(d["H_px_to_mm"],float) if d.get("H_px_to_mm") else None
        Hi=np.linalg.inv(H) if H is not None else None
        return cls(H,Hi,tuple(d.get("center_px")) if d.get("center_px") else None,d.get("radius_px"))

    def save(self,path:str):
        os.makedirs(os.path.dirname(path) or ".",exist_ok=True)
        json.dump({"H_px_to_mm":None if self.H_px_to_mm is None else self.H_px_to_mm.tolist(),
                   "center_px":self.center_px,"radius_px":self.radius_px},open(path,"w"),indent=2)

    def px_to_mm(self,p:tuple[float,float])->tuple[float,float]:
        if self.H_px_to_mm is None: raise RuntimeError("no homography calibration")
        q=cv2.perspectiveTransform(np.array([[[p[0],p[1]]]],np.float32),self.H_px_to_mm)[0,0]
        return float(q[0]),float(q[1])

    def mm_to_px(self,p:tuple[float,float])->tuple[float,float]:
        if self.H_mm_to_px is None: raise RuntimeError("no homography calibration")
        q=cv2.perspectiveTransform(np.array([[[p[0],p[1]]]],np.float32),self.H_mm_to_px)[0,0]
        return float(q[0]),float(q[1])


def homography_from_cardinal_points(points_px:list[tuple[float,float]],radius_mm:float)->PlateCalibration:
    """points order: +X/right, +Y/up, -X/left, -Y/down in plate coordinates."""
    src=np.array(points_px,np.float32)
    dst=np.array([[radius_mm,0],[0,radius_mm],[-radius_mm,0],[0,-radius_mm]],np.float32)
    H=cv2.getPerspectiveTransform(src,dst)
    center=cv2.perspectiveTransform(np.array([[[0.,0.]]],np.float32),np.linalg.inv(H))[0,0]
    r=float(sum(np.linalg.norm(src-center,axis=1))/4)
    return PlateCalibration(H,np.linalg.inv(H),(float(center[0]),float(center[1])),r)
