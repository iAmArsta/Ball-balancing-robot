"""Constant-velocity Kalman filter for ball position and velocity."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from .config import KalmanConfig

@dataclass
class BallState:
    x_mm: float=0.0; y_mm: float=0.0
    vx_mm_s: float=0.0; vy_mm_s: float=0.0
    valid: bool=False

class BallKalman:
    def __init__(self, cfg: KalmanConfig) -> None:
        self.cfg=cfg; self.x=np.zeros((4,1)); self.P=np.eye(4); self.initialized=False

    def reset(self) -> None:
        self.__init__(self.cfg)

    def _FQ(self, dt: float):
        F=np.array([[1,0,dt,0],[0,1,0,dt],[0,0,1,0],[0,0,0,1]],float)
        q=self.cfg.process_accel_sigma_mm_s2**2
        Q=q*np.array([[dt**4/4,0,dt**3/2,0],[0,dt**4/4,0,dt**3/2],
                      [dt**3/2,0,dt**2,0],[0,dt**3/2,0,dt**2]],float)
        return F,Q

    def predict(self, dt: float) -> BallState:
        if not self.initialized: return BallState(valid=False)
        F,Q=self._FQ(max(1e-4,dt)); self.x=F@self.x; self.P=F@self.P@F.T+Q
        return self.state()

    def update(self, x_mm: float, y_mm: float) -> bool:
        z=np.array([[x_mm],[y_mm]],float)
        if not self.initialized:
            self.x[:2]=z
            self.P=np.diag([self.cfg.initial_position_sigma_mm**2]*2+[self.cfg.initial_velocity_sigma_mm_s**2]*2)
            self.initialized=True; return True
        H=np.array([[1,0,0,0],[0,1,0,0]],float)
        R=np.eye(2)*self.cfg.measurement_sigma_mm**2
        innovation=z-H@self.x
        if float(np.linalg.norm(innovation)) > self.cfg.gate_distance_mm: return False
        S=H@self.P@H.T+R; K=self.P@H.T@np.linalg.inv(S)
        self.x=self.x+K@innovation; self.P=(np.eye(4)-K@H)@self.P
        return True

    def state(self)->BallState:
        if not self.initialized:return BallState(valid=False)
        v=self.x.ravel(); return BallState(*map(float,v),valid=True)
