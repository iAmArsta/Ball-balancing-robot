"""PID with derivative filtering, clamping and back-calculation anti-windup."""
from __future__ import annotations
import math
from dataclasses import dataclass

@dataclass
class PIDTerms:
    p: float = 0.0
    i: float = 0.0
    d: float = 0.0
    unsat: float = 0.0
    output: float = 0.0

class PIDController:
    def __init__(self, kp: float, ki: float, kd: float, output_limit: float,
                 integral_limit: float, derivative_cutoff_hz: float,
                 deadband: float, anti_windup_gain: float) -> None:
        self.kp, self.ki, self.kd = kp, ki, kd
        self.output_limit = abs(output_limit)
        self.integral_limit = abs(integral_limit)
        self.derivative_cutoff_hz = max(0.01, derivative_cutoff_hz)
        self.deadband = abs(deadband)
        self.anti_windup_gain = anti_windup_gain
        self.integral = 0.0
        self.prev_error: float | None = None
        self.d_filtered = 0.0
        self.terms = PIDTerms()

    def reset(self) -> None:
        self.integral = 0.0
        self.prev_error = None
        self.d_filtered = 0.0
        self.terms = PIDTerms()

    def update(self, error: float, dt: float) -> float:
        dt = max(1e-4, dt)
        if abs(error) < self.deadband:
            error = 0.0
        raw_d = 0.0 if self.prev_error is None else (error - self.prev_error) / dt
        # 1st order low-pass derivative filter.
        tau = 1.0 / (2.0 * math.pi * self.derivative_cutoff_hz)
        alpha = dt / (tau + dt)
        self.d_filtered += alpha * (raw_d - self.d_filtered)
        self.prev_error = error

        candidate_i = max(-self.integral_limit, min(self.integral_limit, self.integral + error * dt))
        p = self.kp * error
        i = self.ki * candidate_i
        d = self.kd * self.d_filtered
        unsat = p + i + d
        out = max(-self.output_limit, min(self.output_limit, unsat))
        # Back-calculation: unwind integral when saturation opposes recovery.
        if self.ki != 0.0:
            candidate_i += self.anti_windup_gain * (out - unsat) * dt / abs(self.ki)
        self.integral = max(-self.integral_limit, min(self.integral_limit, candidate_i))
        self.terms = PIDTerms(p, self.ki * self.integral, d, unsat, out)
        return out
