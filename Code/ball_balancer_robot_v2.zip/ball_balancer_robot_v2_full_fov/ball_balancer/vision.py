"""Camera Module 3 capture, HSV ball detector and calibrated coordinate mapping."""
from __future__ import annotations
from dataclasses import dataclass
import time, json, cv2, numpy as np
from pathlib import Path
from .config import CameraConfig, ROOT
from .calibration import PlateCalibration

@dataclass
class BallObservation:
    found:bool; x_mm:float=0.; y_mm:float=0.; center_px:tuple[float,float]|None=None
    radius_px:float=0.; circularity:float=0.; timestamp:float=0.; frame:np.ndarray|None=None; mask:np.ndarray|None=None
    diagnosis:str=""; candidate_px:tuple[float,float]|None=None; candidate_radius_px:float=0.

class BallTracker:
    def __init__(self,cfg:CameraConfig,plate_radius_mm:float):
        self.cfg=cfg; self.plate_radius_mm=plate_radius_mm; self.cal=PlateCalibration.load(cfg.calibration_file)
        self._load_detection_settings()
        self.picam=None; self.missing=0; self._start()
    def _load_detection_settings(self):
        """Read values saved by the HSV tuner, without overwriting geometry config."""
        path = ROOT / "ball_detection.json"
        if not path.exists():
            return
        with path.open(encoding="utf-8") as file:
            values = json.load(file)
        fields = {
            "hsv_lower", "hsv_upper", "min_ball_radius_px", "max_ball_radius_px",
            "min_contour_area_px", "min_circularity", "morphology_kernel",
        }
        for name in fields:
            if name in values:
                value = values[name]
                if name in ("hsv_lower", "hsv_upper"):
                    if len(value) != 3:
                        raise ValueError(f"Expected 3 HSV values for {name}")
                    value = tuple(map(int, value))
                setattr(self.cfg, name, value)
        print(f"Loaded detection settings from {path}")

    def _start(self):
        try:
            from picamera2 import Picamera2
            from libcamera import controls
        except ImportError as e: raise RuntimeError("Picamera2 missing; install python3-picamera2") from e
        self.picam = Picamera2()

        kwargs = {
            "main": {
                "size": (self.cfg.width, self.cfg.height),
                "format": "RGB888",
            },
            "controls": {"FrameRate": float(self.cfg.fps)},
            "buffer_count": 4,
        }

        # Camera Module 3 Wide: explicitly request the 2304x1296 binned
        # sensor mode so Picamera2/libcamera does not switch to a cropped
        # high-speed mode merely to satisfy the requested frame rate.
        if self.cfg.force_sensor_mode:
            kwargs["sensor"] = {
                "output_size": tuple(self.cfg.sensor_output_size),
                "bit_depth": int(self.cfg.sensor_bit_depth),
            }

        conf = self.picam.create_video_configuration(**kwargs)
        self.picam.configure(conf)

        # Print the selected configuration once so it is easy to confirm
        # that the requested full-FOV sensor mode was accepted on the Pi.
        try:
            selected = self.picam.camera_configuration()
            sensor_cfg = selected.get("sensor", {})
            print(
                "Camera configured:",
                f"main={selected.get('main', {}).get('size')}",
                f"sensor={sensor_cfg.get('output_size')}",
                f"bit_depth={sensor_cfg.get('bit_depth')}",
                f"fps={self.cfg.fps}",
            )
        except Exception:
            pass

        self.picam.start(); time.sleep(.4)
        if self.cfg.autofocus_mode=="continuous": self.picam.set_controls({"AfMode":controls.AfModeEnum.Continuous})
        elif self.cfg.autofocus_mode=="manual": self.picam.set_controls({"AfMode":controls.AfModeEnum.Manual,"LensPosition":float(self.cfg.manual_lens_position)})
    def capture_roi(self):
        rgb=self.picam.capture_array("main"); bgr=cv2.cvtColor(rgb,cv2.COLOR_RGB2BGR)
        x,y,w,h=self.cfg.roi; return bgr[y:y+h,x:x+w].copy()
    def _map(self,cx,cy,w,h):
        if self.cal.H_px_to_mm is not None: return self.cal.px_to_mm((cx,cy))
        center=self.cfg.plate_center_px or (w/2,h/2); scale=self.plate_radius_mm/self.cfg.plate_radius_px
        x=(cx-center[0])*scale; y=(cy-center[1])*scale
        if self.cfg.swap_xy:x,y=y,x
        if self.cfg.invert_x:x=-x
        if self.cfg.invert_y:y=-y
        return x,y
    def read(self)->BallObservation:
        frame=self.capture_roi(); hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
        mask=cv2.inRange(hsv,np.array(self.cfg.hsv_lower),np.array(self.cfg.hsv_upper))
        k=max(3,self.cfg.morphology_kernel|1); ker=np.ones((k,k),np.uint8)
        mask=cv2.morphologyEx(mask,cv2.MORPH_OPEN,ker); mask=cv2.morphologyEx(mask,cv2.MORPH_CLOSE,ker,iterations=2)
        contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        best=None; score=-1.; rejected=[]
        # Rejection reasons are displayed in both the HSV tuner and dry run.
        for c in contours:
            area=float(cv2.contourArea(c)); per=float(cv2.arcLength(c,True))
            if per<=0:continue
            circ=float(4*np.pi*area/(per*per)); (cx,cy),r=cv2.minEnclosingCircle(c)
            reason=None
            if area<self.cfg.min_contour_area_px: reason=f"area {area:.0f} < {self.cfg.min_contour_area_px:g}"
            elif r<self.cfg.min_ball_radius_px: reason=f"radius {r:.1f} < {self.cfg.min_ball_radius_px:g}"
            elif r>self.cfg.max_ball_radius_px: reason=f"radius {r:.1f} > {self.cfg.max_ball_radius_px:g}"
            elif circ<self.cfg.min_circularity: reason=f"circularity {circ:.2f} < {self.cfg.min_circularity:.2f}"
            if reason:
                rejected.append((area,(cx,cy),r,reason))
            else:
                this_score=area*circ
                if this_score>score:best=(cx,cy,r,circ,area);score=this_score
        now=time.monotonic()
        if best is None:
            self.missing+=1
            if rejected:
                area,candidate,r,reason=max(rejected,key=lambda c:c[0])
                desc=f"REJECTED: {reason} ({len(contours)} contours)"
                return BallObservation(False,timestamp=now,frame=frame,mask=mask,
                                       diagnosis=desc,candidate_px=candidate,candidate_radius_px=r)
            desc="NO HSV OBJECT (mask empty)" if cv2.countNonZero(mask)==0 else "NO USABLE CONTOUR"
            return BallObservation(False,timestamp=now,frame=frame,mask=mask,diagnosis=desc)
        self.missing=0;cx,cy,r,circ,area=best;x,y=self._map(cx,cy,frame.shape[1],frame.shape[0])
        desc=f"ACCEPTED: radius {r:.1f}px, area {area:.0f}px2, circularity {circ:.2f}"
        return BallObservation(True,x,y,(cx,cy),r,circ,now,frame,mask,desc)
    def draw_tuning_debug(self,obs):
        """Draw candidate outlines and a human-readable rejection reason."""
        f=obs.frame.copy()
        if obs.found:
            cv2.circle(f,tuple(map(round,obs.center_px)),round(obs.radius_px),(0,255,0),2)
            cv2.drawMarker(f,tuple(map(round,obs.center_px)),(0,255,0),cv2.MARKER_CROSS,12,2)
        elif obs.candidate_px is not None:
            cv2.circle(f,tuple(map(round,obs.candidate_px)),round(obs.candidate_radius_px),(0,0,255),2)
        cv2.rectangle(f,(0,0),(min(f.shape[1]-1,1060),42),(0,0,0),-1)
        cv2.putText(f,obs.diagnosis[:95],(8,27),cv2.FONT_HERSHEY_SIMPLEX,.65,
                    (0,220,0) if obs.found else (0,160,255),2,cv2.LINE_AA)
        return f
    def draw_debug(self,obs,state,target,pose,servo_cmd,fps):
        f=obs.frame.copy(); h,w=f.shape[:2]
        center=self.cal.center_px or self.cfg.plate_center_px or (w/2,h/2); rad=self.cal.radius_px or self.cfg.plate_radius_px
        cv2.circle(f,(round(center[0]),round(center[1])),round(rad),(180,180,180),1);cv2.drawMarker(f,(round(center[0]),round(center[1])),(255,255,255),cv2.MARKER_CROSS,16,1)
        if self.cal.H_mm_to_px is not None:
            tx,ty=self.cal.mm_to_px(target);cv2.drawMarker(f,(round(tx),round(ty)),(0,255,255),cv2.MARKER_TILTED_CROSS,18,2)
        if obs.found:
            cv2.circle(f,(round(obs.center_px[0]),round(obs.center_px[1])),round(obs.radius_px),(0,255,0),2)
        elif obs.candidate_px is not None:
            cv2.circle(f,tuple(map(round,obs.candidate_px)),round(obs.candidate_radius_px),(0,0,255),2)
        lines=[obs.diagnosis[:100], f"ball {state.x_mm:+.1f},{state.y_mm:+.1f} mm  v {state.vx_mm_s:+.1f},{state.vy_mm_s:+.1f}",
               f"roll {pose[0]:+.2f} pitch {pose[1]:+.2f} deg",f"servo {[round(v,1) for v in servo_cmd]}",f"fps {fps:.1f}  {'FOUND' if obs.found else 'LOST'}"]
        for i,t in enumerate(lines):cv2.putText(f,t,(8,22+20*i),cv2.FONT_HERSHEY_SIMPLEX,.48,(0,255,255),1,cv2.LINE_AA)
        return f
    def close(self):
        if self.picam is not None:self.picam.stop();self.picam.close()
