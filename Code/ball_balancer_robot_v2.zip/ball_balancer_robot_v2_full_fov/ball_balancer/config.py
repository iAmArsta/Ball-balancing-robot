"""Central configuration for the 3-servo Raspberry Pi ball balancer.

Units: mm, seconds, degrees in config; radians inside kinematics.
Edit this file first for your machine.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Tuple

ROOT = Path(__file__).resolve().parents[1]

@dataclass
class GeometryConfig:
    servo_circle_radius_mm: float = 71.25
    arm1_length_mm: float = 62.0       # servo horn, shaft center -> rod joint
    arm2_length_mm: float = 94.0       # connecting rod, joint center -> joint center
    plate_joint_radius_mm: float = 90.0
    plate_radius_mm: float = 75.0
    plate_height_mm: float = 90.0      # level plate joint plane above servo shaft plane
    first_servo_azimuth_deg: float = 90.0
    plate_joint_azimuth_offset_deg: float = 0.0
    horn_radial_direction: float = 1.0 # +1 outward, -1 inward at zero horn angle
    ik_min_angle_deg: float = -80.0
    ik_max_angle_deg: float = 130.0
    ik_reference_angle_deg: float = 80.0

@dataclass
class ServoChannelConfig:
    channel: int
    neutral_deg: float = 90.0
    direction: int = 1
    horn_zero_deg: float = 81.0        # IK horn angle that maps to neutral_deg
    offset_deg: float = 0.0
    min_deg: float = 10.0
    max_deg: float = 170.0
    min_pulse_us: int = 500
    max_pulse_us: int = 2500
    actuation_range_deg: float = 180.0

@dataclass
class ServoConfig:
    i2c_address: int = 0x40
    pwm_frequency_hz: int = 50
    channels: Tuple[ServoChannelConfig, ...] = field(default_factory=lambda: (
        ServoChannelConfig(channel=0),
        ServoChannelConfig(channel=1),
        ServoChannelConfig(channel=2),
    ))
    max_speed_deg_per_s: float = 240.0
    max_accel_deg_per_s2: float = 1200.0
    command_deadband_deg: float = 0.12
    startup_move_time_s: float = 1.0
    disable_outputs_on_exit: bool = False

@dataclass
class CameraConfig:
    # 16:9 processing stream, derived from the Camera Module 3 Wide full-FOV
    # 2x2-binned sensor mode below. 50 fps leaves headroom versus the
    # full-FOV sensor mode limit and avoids libcamera selecting a cropped
    # high-speed mode.
    width: int = 1280
    height: int = 720
    fps: int = 50

    # Force a wide/full-FOV sensor mode, then scale it to width x height.
    force_sensor_mode: bool = True
    sensor_output_size: Tuple[int, int] = (2304, 1296)
    sensor_bit_depth: int = 10

    # Full output frame: no software crop. Format is (x, y, width, height).
    roi: Tuple[int, int, int, int] = (0, 0, 1280, 720)
    autofocus_mode: str = "continuous"  # continuous/manual/off
    manual_lens_position: float = 8.0
    calibration_file: str = str(ROOT / "calibration.json")
    # Fallback mapping if calibration.json does not exist.
    plate_center_px: Tuple[float, float] | None = None
    plate_radius_px: float = 220.0
    swap_xy: bool = False
    invert_x: bool = False
    invert_y: bool = True
    hsv_lower: Tuple[int, int, int] = (67, 73, 122)
    hsv_upper: Tuple[int, int, int] = (129, 255, 255)
    min_ball_radius_px: float = 8.0
    max_ball_radius_px: float = 130.0
    min_contour_area_px: float = 100.0
    min_circularity: float = 0.55
    morphology_kernel: int = 5
    max_missing_frames: int = 12
    show_debug_window: bool = True

@dataclass
class KalmanConfig:
    process_accel_sigma_mm_s2: float = 850.0
    measurement_sigma_mm: float = 1.8
    initial_position_sigma_mm: float = 15.0
    initial_velocity_sigma_mm_s: float = 150.0
    gate_distance_mm: float = 35.0

@dataclass
class PIDAxisConfig:
    kp: float = 0.12
    ki: float = 0.003
    kd: float = 0.075
    output_limit_deg: float = 8.0
    integral_limit: float = 160.0
    derivative_cutoff_hz: float = 10.0
    deadband_mm: float = 0.6
    anti_windup_gain: float = 0.6

@dataclass
class ControlConfig:
    x_pid: PIDAxisConfig = field(default_factory=PIDAxisConfig)
    y_pid: PIDAxisConfig = field(default_factory=PIDAxisConfig)
    target_x_mm: float = 0.0
    target_y_mm: float = 0.0
    control_rate_hz: float = 60.0
    max_plate_tilt_deg: float = 2.0
    pitch_from_x_sign: float = 1.0
    roll_from_y_sign: float = -1.0
    # Feed-forward damping from estimated ball velocity.
    velocity_damping_x_deg_per_mm_s: float = 0.010
    velocity_damping_y_deg_per_mm_s: float = 0.010
    trim_roll_deg: float = 0.0
    trim_pitch_deg: float = 0.0
    lost_ball_level_delay_s: float = 0.25
    lost_ball_level_rate_deg_per_s: float = 20.0
    max_dt_s: float = 0.08

@dataclass
class LoggingConfig:
    enabled: bool = True
    directory: str = str(ROOT / "logs")
    flush_every_n_rows: int = 30

@dataclass
class LevelingConfig:
    enabled: bool = False
    warmup_s: float = 2.0
    sample_s: float = 8.0
    max_correction_deg: float = 3.0
    correction_gain_deg_per_mm_s: float = 0.04

@dataclass
class AppConfig:
    geometry: GeometryConfig = field(default_factory=GeometryConfig)
    servos: ServoConfig = field(default_factory=ServoConfig)
    camera: CameraConfig = field(default_factory=CameraConfig)
    kalman: KalmanConfig = field(default_factory=KalmanConfig)
    control: ControlConfig = field(default_factory=ControlConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    leveling: LevelingConfig = field(default_factory=LevelingConfig)
    dry_run: bool = False

CONFIG = AppConfig()
