from __future__ import annotations
import csv,time,os
from .config import LoggingConfig
class DataLogger:
    FIELDS=['t','found','x_mm','y_mm','vx_mm_s','vy_mm_s','target_x','target_y','roll_deg','pitch_deg','horn1','horn2','horn3','servo1','servo2','servo3','loop_hz']
    def __init__(self,cfg:LoggingConfig):
        self.cfg=cfg;self.f=None;self.writer=None;self.n=0;self.path=None
        if cfg.enabled:
            os.makedirs(cfg.directory,exist_ok=True);self.path=os.path.join(cfg.directory,time.strftime('run_%Y%m%d_%H%M%S.csv'))
            self.f=open(self.path,'w',newline='');self.writer=csv.DictWriter(self.f,fieldnames=self.FIELDS);self.writer.writeheader()
    def write(self,**kw):
        if not self.writer:return
        self.writer.writerow({k:kw.get(k,'') for k in self.FIELDS});self.n+=1
        if self.n%self.cfg.flush_every_n_rows==0:self.f.flush()
    def close(self):
        if self.f:self.f.close()
