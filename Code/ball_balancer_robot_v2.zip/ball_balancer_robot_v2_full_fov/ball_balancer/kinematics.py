"""Analytic inverse kinematics for a symmetric three-RRS platform.

Each servo horn rotates in a vertical radial plane. The horn tip is connected by
one fixed-length rod to the matching plate joint. The three legs are separated
by 120 degrees.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np
from .config import GeometryConfig

class KinematicsError(RuntimeError): pass

@dataclass(frozen=True)
class PlatePose:
    roll_deg: float = 0.0
    pitch_deg: float = 0.0
    height_mm: float | None = None


def rotation_matrix(roll: float, pitch: float) -> np.ndarray:
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    rx = np.array([[1.,0.,0.],[0.,cr,-sr],[0.,sr,cr]])
    ry = np.array([[cp,0.,sp],[0.,1.,0.],[-sp,0.,cp]])
    return ry @ rx

class ThreeRRSKinematics:
    def __init__(self, cfg: GeometryConfig) -> None:
        self.cfg = cfg
        self.last = np.full(3, math.radians(cfg.ik_reference_angle_deg))

    def azimuths(self) -> list[float]:
        p0 = math.radians(self.cfg.first_servo_azimuth_deg)
        return [p0 + i*2*math.pi/3 for i in range(3)]

    def solve(self, pose: PlatePose) -> list[float]:
        R = rotation_matrix(math.radians(pose.roll_deg), math.radians(pose.pitch_deg))
        h = self.cfg.plate_height_mm if pose.height_mm is None else pose.height_mm
        out: list[float] = []
        for i, phi in enumerate(self.azimuths()):
            radial = np.array([math.cos(phi), math.sin(phi), 0.])
            B = self.cfg.servo_circle_radius_mm * radial
            q = phi + math.radians(self.cfg.plate_joint_azimuth_offset_deg)
            P0 = np.array([self.cfg.plate_joint_radius_mm*math.cos(q),
                           self.cfg.plate_joint_radius_mm*math.sin(q), 0.])
            P = np.array([0.,0.,h]) + R @ P0
            delta = P - B
            # Horn tip H = B + L1*(dir*cos(a)*radial + sin(a)*z_hat)
            dr = self.cfg.horn_radial_direction * float(np.dot(delta, radial))
            dz = float(delta[2])
            l1, l2 = self.cfg.arm1_length_mm, self.cfg.arm2_length_mm
            C = (float(np.dot(delta,delta)) + l1*l1 - l2*l2)/(2*l1)
            A = math.hypot(dr,dz)
            if A < 1e-9 or abs(C) > A + 1e-6:
                raise KinematicsError(f"leg {i+1}: unreachable pose (C/A={C/A if A else float('inf'):.3f})")
            phase = math.atan2(dz, dr)
            offs = math.acos(max(-1., min(1., C/A)))
            candidates = [phase+offs, phase-offs]
            lo, hi = map(math.radians, (self.cfg.ik_min_angle_deg, self.cfg.ik_max_angle_deg))
            valid = [a for a in candidates if lo <= a <= hi]
            if not valid:
                raise KinematicsError(f"leg {i+1}: IK solutions outside limits: {[round(math.degrees(a),2) for a in candidates]}")
            chosen = min(valid, key=lambda a: abs(self._wrap(a-self.last[i])))
            self.last[i] = chosen
            out.append(math.degrees(chosen))
        return out

    @staticmethod
    def _wrap(a: float) -> float:
        return (a + math.pi) % (2*math.pi) - math.pi

    def workspace_check(self, max_tilt_deg: float, steps: int = 7) -> list[str]:
        errors=[]
        for r in np.linspace(-max_tilt_deg,max_tilt_deg,steps):
            for p in np.linspace(-max_tilt_deg,max_tilt_deg,steps):
                try: self.solve(PlatePose(float(r),float(p)))
                except KinematicsError as e: errors.append(f"roll={r:.1f}, pitch={p:.1f}: {e}")
        return errors
