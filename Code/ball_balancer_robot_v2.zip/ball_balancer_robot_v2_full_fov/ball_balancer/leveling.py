"""Practical drift-based trim estimation.

This does not replace a spirit level/IMU. With the ball near center, it averages
Kalman-estimated ball velocity and proposes small roll/pitch trim corrections.
"""
from __future__ import annotations
from dataclasses import dataclass
from .config import LevelingConfig,ControlConfig
@dataclass
class LevelResult: roll_trim_deg:float; pitch_trim_deg:float; avg_vx:float; avg_vy:float
class DriftLeveler:
    def __init__(self,cfg:LevelingConfig,control:ControlConfig):self.cfg=cfg;self.control=control
    def estimate(self,samples:list[tuple[float,float]])->LevelResult:
        if not samples:return LevelResult(self.control.trim_roll_deg,self.control.trim_pitch_deg,0,0)
        vx=sum(x for x,_ in samples)/len(samples);vy=sum(y for _,y in samples)/len(samples)
        # compensate drift by tilting uphill; signs follow controller mappings
        dp=-self.control.pitch_from_x_sign*vx*self.cfg.correction_gain_deg_per_mm_s
        dr=-self.control.roll_from_y_sign*vy*self.cfg.correction_gain_deg_per_mm_s
        lim=self.cfg.max_correction_deg
        return LevelResult(max(-lim,min(lim,self.control.trim_roll_deg+dr)),max(-lim,min(lim,self.control.trim_pitch_deg+dp)),vx,vy)
