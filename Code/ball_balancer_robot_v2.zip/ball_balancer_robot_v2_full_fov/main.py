#!/usr/bin/env python3
from __future__ import annotations
import argparse,signal,time,cv2
from ball_balancer.config import CONFIG
from ball_balancer.vision import BallTracker
from ball_balancer.tracking import BallKalman,BallState
from ball_balancer.controller import PlateController
from ball_balancer.kinematics import ThreeRRSKinematics,PlatePose,KinematicsError
from ball_balancer.servos import ServoController
from ball_balancer.logger import DataLogger


def args():
    p=argparse.ArgumentParser(description='3-servo Raspberry Pi ball balancer')
    p.add_argument('--dry-run',action='store_true',help='camera/control/IK only; no servo output')
    p.add_argument('--no-window',action='store_true')
    p.add_argument('--debug-mask',action='store_true',help='show exact processed mask used by ball detector')
    p.add_argument('--workspace-check',action='store_true',help='check configured tilt workspace then exit')
    return p.parse_args()

def approach(v,t,step): return v+max(-step,min(step,t-v))

def main():
    a=args(); CONFIG.dry_run|=a.dry_run
    if a.no_window:CONFIG.camera.show_debug_window=False
    ik=ThreeRRSKinematics(CONFIG.geometry)
    if a.workspace_check:
        errs=ik.workspace_check(CONFIG.control.max_plate_tilt_deg)
        print('Workspace OK' if not errs else '\n'.join(errs[:30]));return
    servos=ServoController(CONFIG.servos,CONFIG.dry_run)
    tracker=BallTracker(CONFIG.camera,CONFIG.geometry.plate_radius_mm)
    filt=BallKalman(CONFIG.kalman); ctrl=PlateController(CONFIG.control); log=DataLogger(CONFIG.logging)
    level=ik.solve(PlatePose(CONFIG.control.trim_roll_deg,CONFIG.control.trim_pitch_deg))
    print('Level horn angles:',[round(x,2) for x in level])
    print('PCA9685 channels:',[c.channel for c in CONFIG.servos.channels])
    if not CONFIG.dry_run:servos.move_to_horn_angles(level)
    running=True
    def stop(*_):
        nonlocal running;running=False
    signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
    prev=time.monotonic();last_seen=prev;roll=CONFIG.control.trim_roll_deg;pitch=CONFIG.control.trim_pitch_deg
    period=1/CONFIG.control.control_rate_hz;fps=0.;servo_cmd=servos.last[:]
    try:
        while running:
            t0=time.monotonic();dt=max(1e-4,min(CONFIG.control.max_dt_s,t0-prev));prev=t0
            pred=filt.predict(dt);obs=tracker.read()
            if obs.found:
                filt.update(obs.x_mm,obs.y_mm);last_seen=t0
            state=filt.state() if filt.initialized else BallState(valid=False)
            if obs.found and state.valid:
                roll,pitch=ctrl.update(state,dt)
            elif t0-last_seen>CONFIG.control.lost_ball_level_delay_s:
                ctrl.reset();step=CONFIG.control.lost_ball_level_rate_deg_per_s*dt
                roll=approach(roll,CONFIG.control.trim_roll_deg,step);pitch=approach(pitch,CONFIG.control.trim_pitch_deg,step)
            try:
                horns=ik.solve(PlatePose(roll,pitch));servo_cmd=servos.command_horn_angles(horns,dt)
            except KinematicsError as e:
                print('IK safety fallback:',e);ctrl.reset();roll=CONFIG.control.trim_roll_deg;pitch=CONFIG.control.trim_pitch_deg
                horns=level;servo_cmd=servos.command_horn_angles(horns,dt)
            loop=time.monotonic()-t0;inst=1/max(loop,1e-6);fps=inst if fps==0 else .9*fps+.1*inst
            log.write(t=t0,found=int(obs.found),x_mm=state.x_mm if state.valid else '',y_mm=state.y_mm if state.valid else '',
                      vx_mm_s=state.vx_mm_s if state.valid else '',vy_mm_s=state.vy_mm_s if state.valid else '',
                      target_x=CONFIG.control.target_x_mm,target_y=CONFIG.control.target_y_mm,roll_deg=roll,pitch_deg=pitch,
                      horn1=horns[0],horn2=horns[1],horn3=horns[2],servo1=servo_cmd[0],servo2=servo_cmd[1],servo3=servo_cmd[2],loop_hz=fps)
            if CONFIG.camera.show_debug_window:
                dbg=tracker.draw_debug(obs,state,(CONFIG.control.target_x_mm,CONFIG.control.target_y_mm),(roll,pitch),servo_cmd,fps)
                cv2.imshow('Ball Balancer v2',dbg)
                if a.debug_mask and obs.mask is not None:cv2.imshow('Mask used by detector',obs.mask)
                key=cv2.waitKey(1)&0xff
                if key in (27,ord('q')):break
                if key==ord('r'):ctrl.reset();filt.reset()
            sleep=period-(time.monotonic()-t0)
            if sleep>0:time.sleep(sleep)
    finally:
        try:servos.move_to_horn_angles(level,.5)
        except Exception:pass
        log.close();tracker.close();servos.close();cv2.destroyAllWindows()
        if log.path:print('Log:',log.path)
if __name__=='__main__':main()
