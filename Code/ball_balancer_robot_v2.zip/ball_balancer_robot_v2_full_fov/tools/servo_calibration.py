#!/usr/bin/env python3
"""Interactive raw-servo calibration. Run from project root:
python -m tools.servo_calibration
Disconnect rods/plate first.
"""
from pathlib import Path
import sys

# Allow both `python -m tools.NAME` and `python tools/NAME.py`.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ball_balancer.config import CONFIG
from ball_balancer.servos import ServoController

def main():
    s=ServoController(CONFIG.servos,False)
    print('Channels:',[c.channel for c in CONFIG.servos.channels])
    print('Commands: 1/2/3 select servo, angle e.g. 90, + / - by 1 deg, q quit')
    idx=0
    try:
        while True:
            raw=input(f'servo {idx+1} ch{CONFIG.servos.channels[idx].channel} angle={s.last[idx]:.1f}> ').strip().lower()
            if raw=='q':break
            if raw in ('1','2','3'):idx=int(raw)-1;continue
            if raw=='+':v=s.last[idx]+1
            elif raw=='-':v=s.last[idx]-1
            else:
                try:v=float(raw)
                except ValueError:continue
            vals=s.last[:];vals[idx]=v;s.command_servo_angles(vals,.05)
    finally:s.close()
if __name__=='__main__':main()
