#!/usr/bin/env python3
"""Live HSV/shape tuner. Unlike v2, SAVES settings automatically."""
from pathlib import Path
import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import json
import cv2
from ball_balancer.config import CONFIG, ROOT
from ball_balancer.vision import BallTracker

DETECTION_FILE = ROOT / "ball_detection.json"


def main():
    detector = BallTracker(CONFIG.camera, CONFIG.geometry.plate_radius_mm)
    win = "HSV + detection thresholds (press q to SAVE)"
    cv2.namedWindow(win, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(win, 1080, 640)
    fields = [
        ("Hlo", CONFIG.camera.hsv_lower[0], 179),
        ("Slo", CONFIG.camera.hsv_lower[1], 255),
        ("Vlo", CONFIG.camera.hsv_lower[2], 255),
        ("Hhi", CONFIG.camera.hsv_upper[0], 179),
        ("Shi", CONFIG.camera.hsv_upper[1], 255),
        ("Vhi", CONFIG.camera.hsv_upper[2], 255),
        ("min_radius", round(CONFIG.camera.min_ball_radius_px), 200),
        ("max_radius", round(CONFIG.camera.max_ball_radius_px), 400),
        ("min_area", round(CONFIG.camera.min_contour_area_px), 5000),
        ("min_circ_pct", round(CONFIG.camera.min_circularity * 100), 100),
        ("morph_kernel", CONFIG.camera.morphology_kernel, 21),
    ]
    for label, value, upper in fields:
        cv2.createTrackbar(label, win, max(0,int(value)), upper, lambda _:None)
    try:
        while True:
            v={name:cv2.getTrackbarPos(name,win) for name,_,_ in fields}
            detector.cfg.hsv_lower=(v["Hlo"],v["Slo"],v["Vlo"])
            detector.cfg.hsv_upper=(v["Hhi"],v["Shi"],v["Vhi"])
            detector.cfg.min_ball_radius_px=max(1,v["min_radius"])
            detector.cfg.max_ball_radius_px=max(detector.cfg.min_ball_radius_px+1,v["max_radius"])
            detector.cfg.min_contour_area_px=max(1,v["min_area"])
            detector.cfg.min_circularity=v["min_circ_pct"]/100.0
            detector.cfg.morphology_kernel=max(1,v["morph_kernel"])
            obs=detector.read() # same filtering as main.py, NOT a raw HSV mask
            cv2.imshow("Camera + detection decision",detector.draw_tuning_debug(obs))
            cv2.imshow("Mask actually used by main.py",obs.mask)
            # Keep trackbar window alive
            cv2.imshow(win,obs.frame)
            key=cv2.waitKey(1)&0xff
            if key in (ord('q'),27):break
    finally:
        values = {
            "hsv_lower": list(detector.cfg.hsv_lower),
            "hsv_upper": list(detector.cfg.hsv_upper),
            "min_ball_radius_px": detector.cfg.min_ball_radius_px,
            "max_ball_radius_px": detector.cfg.max_ball_radius_px,
            "min_contour_area_px": detector.cfg.min_contour_area_px,
            "min_circularity": detector.cfg.min_circularity,
            "morphology_kernel": detector.cfg.morphology_kernel,
        }
        DETECTION_FILE.write_text(json.dumps(values,indent=2)+"\n",encoding="utf-8")
        print(f"Saved detection settings to: {DETECTION_FILE}")
        print("Detection settings:",json.dumps(values))
        detector.close()
        cv2.destroyAllWindows()

if __name__=="__main__":
    main()
