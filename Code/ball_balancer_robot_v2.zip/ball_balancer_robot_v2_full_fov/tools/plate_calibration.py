#!/usr/bin/env python3
"""Click plate cardinal points to build pixel->mm homography.
Order: +X/right, +Y/up, -X/left, -Y/down in YOUR desired plate coordinates.
For a camera viewed underneath, this lets you deliberately define axis signs.
"""
from pathlib import Path
import sys

# Allow both `python -m tools.NAME` and `python tools/NAME.py`.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ball_balancer.config import CONFIG
from ball_balancer.vision import BallTracker
from ball_balancer.calibration import homography_from_cardinal_points
import cv2

def main():
    tr=BallTracker(CONFIG.camera,CONFIG.geometry.plate_radius_mm);frame=tr.capture_roi();tr.close();pts=[]
    labels=['+X / right','+Y / up','-X / left','-Y / down']
    def click(event,x,y,flags,param):
        if event==cv2.EVENT_LBUTTONDOWN and len(pts)<4:pts.append((x,y))
    cv2.namedWindow('plate calibration');cv2.setMouseCallback('plate calibration',click)
    while len(pts)<4:
        d=frame.copy()
        for i,p in enumerate(pts):cv2.circle(d,p,6,(0,255,0),-1);cv2.putText(d,str(i+1),p,0,.7,(0,255,0),2)
        cv2.putText(d,'Click '+labels[len(pts)],(10,25),0,.65,(0,255,255),2);cv2.imshow('plate calibration',d)
        if cv2.waitKey(20)&0xff in (27,ord('q')):return
    cal=homography_from_cardinal_points(pts,CONFIG.geometry.plate_radius_mm);cal.save(CONFIG.camera.calibration_file)
    print('Saved',CONFIG.camera.calibration_file);print('center_px',cal.center_px,'radius_px',cal.radius_px);cv2.destroyAllWindows()
if __name__=='__main__':main()
