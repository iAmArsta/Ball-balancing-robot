#!/usr/bin/env python3
"""Estimate small static plate trim from ball drift while near level.
Use only after geometry/servo neutral calibration. Keep hands off the robot.
"""
from pathlib import Path
import sys

# Allow both `python -m tools.NAME` and `python tools/NAME.py`.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import time
from ball_balancer.config import CONFIG
from ball_balancer.vision import BallTracker
from ball_balancer.tracking import BallKalman
from ball_balancer.leveling import DriftLeveler

def main():
    tr=BallTracker(CONFIG.camera,CONFIG.geometry.plate_radius_mm);kf=BallKalman(CONFIG.kalman);lev=DriftLeveler(CONFIG.leveling,CONFIG.control)
    print('Place ball near center. Measuring drift...');start=time.monotonic();prev=start;samples=[]
    try:
        while time.monotonic()-start<CONFIG.leveling.warmup_s+CONFIG.leveling.sample_s:
            now=time.monotonic();kf.predict(max(1e-3,now-prev));prev=now;o=tr.read()
            if o.found:kf.update(o.x_mm,o.y_mm)
            if now-start>CONFIG.leveling.warmup_s and kf.initialized:
                s=kf.state();samples.append((s.vx_mm_s,s.vy_mm_s))
    finally:tr.close()
    r=lev.estimate(samples);print(f'avg drift vx={r.avg_vx:+.2f}, vy={r.avg_vy:+.2f} mm/s')
    print(f'Proposed config: trim_roll_deg={r.roll_trim_deg:+.3f}, trim_pitch_deg={r.pitch_trim_deg:+.3f}')
    print('Repeat several times and confirm direction before increasing correction_gain.')
if __name__=='__main__':main()
