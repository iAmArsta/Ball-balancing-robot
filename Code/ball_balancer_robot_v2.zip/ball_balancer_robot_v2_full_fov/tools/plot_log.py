#!/usr/bin/env python3
from pathlib import Path
import sys

# Allow both `python -m tools.NAME` and `python tools/NAME.py`.
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import argparse,csv
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('csv');a=p.parse_args()
r=list(csv.DictReader(open(a.csv)));t=[float(x['t']) for x in r];t=[x-t[0] for x in t]
for key in ('x_mm','y_mm'):
    y=[float(x[key]) if x[key] else float('nan') for x in r];plt.plot(t,y,label=key)
plt.axhline(0,linewidth=1);plt.xlabel('time (s)');plt.ylabel('ball position (mm)');plt.legend();plt.grid(True);plt.show()
