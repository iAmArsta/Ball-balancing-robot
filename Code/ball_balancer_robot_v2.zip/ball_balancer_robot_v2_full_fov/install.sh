#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y python3-venv python3-picamera2 python3-opencv python3-numpy python3-matplotlib i2c-tools
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
printf '\nDone. Activate with: source .venv/bin/activate\n'
printf 'Servo calibration: python -m tools.servo_calibration\n'
printf 'Plate calibration: python -m tools.plate_calibration\n'
printf 'HSV tuner: python -m tools.hsv_tuner\n'
printf 'Safe run: python main.py --dry-run\n'
